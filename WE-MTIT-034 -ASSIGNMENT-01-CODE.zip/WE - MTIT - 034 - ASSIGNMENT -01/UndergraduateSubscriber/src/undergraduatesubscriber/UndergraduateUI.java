package undergraduatesubscriber;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

import undergraduatepublisher.IUndergraduate;
import undergraduatepublishert.Undergraduate;

public class UndergraduateUI {
	private JFrame frame;

	private IUndergraduate undergraduateService;
	
	
	JButton btnHome;
	JButton btnAddUndergraduate;
	JButton btnAllUndergraduates;
	JButton btnUpdateUndergraduate;
	JButton btnRemoveUndergraduate;
	JButton btnFindUndergraduate;

	/**
	 * Create the application.
	 */
	public UndergraduateUI(IUndergraduate undergraduateService) {
		this.undergraduateService = undergraduateService;
		initialize();
	
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new MainUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnAddUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AddUndergraduateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnAllUndergraduates.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AllUndergraduateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnUpdateUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new UpdateUndergraduateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnRemoveUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new RemoveUndergrauateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnFindUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new FindUndergraduateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);
		
		btnHome = new JButton("Home");
		btnHome.setBounds(10, 12, 140, 21);
		frame.getContentPane().add(btnHome);
		
		btnAddUndergraduate = new JButton("Add Undergraduate");
		btnAddUndergraduate.setBounds(10, 55, 140, 21);
		frame.getContentPane().add(btnAddUndergraduate);
		
		btnAllUndergraduates = new JButton("All Undergraduates");
		btnAllUndergraduates.setBounds(10, 98, 140, 21);
		frame.getContentPane().add(btnAllUndergraduates);
		
		btnUpdateUndergraduate = new JButton("Update Undergraduate");
		btnUpdateUndergraduate.setBounds(10, 144, 140, 21);
		frame.getContentPane().add(btnUpdateUndergraduate);
		
		btnRemoveUndergraduate = new JButton("Remove Undergraduate");
		btnRemoveUndergraduate.setBounds(10, 188, 140, 21);
		frame.getContentPane().add(btnRemoveUndergraduate);
		
		btnFindUndergraduate = new JButton("Find Undergraduate");
		btnFindUndergraduate.setBounds(10, 232, 140, 21);
		frame.getContentPane().add(btnFindUndergraduate);
		
		
	}
}
