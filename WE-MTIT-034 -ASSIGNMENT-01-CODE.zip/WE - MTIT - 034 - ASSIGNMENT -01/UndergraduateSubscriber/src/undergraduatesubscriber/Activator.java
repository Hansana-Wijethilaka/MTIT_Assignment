package undergraduatesubscriber;



import undergraduatepublisher.IUndergraduate;

//import org.omg.PortableServer.IdAssignmentPolicy;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;



public class Activator implements BundleActivator{

	private ServiceReference<?> undergraduateReference;
	
	private IUndergraduate undergraduateService;

	
	public void start(BundleContext bundleContext) throws Exception {
		
		undergraduateReference = bundleContext.getServiceReference(IUndergraduate.class.getName());
	
		
		undergraduateService = (IUndergraduate) bundleContext.getService(undergraduateReference);
	
		
		System.out.println("Undergraduate subscriber is started");	
		MainUI frame = new MainUI(undergraduateService);
		frame.setVisible(true);
//		MainUI frame = new MainUI(undergraduateService);
		
	}

	public void stop(BundleContext bundleContext) throws Exception {
		
		bundleContext.ungetService(undergraduateReference);
		
		System.out.println("Undergraduate subscriber is Stopped");	
	}

}
