package undergraduatesubscriber;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import undergraduatepublisher.IUndergraduate;
import undergraduatepublisher.Undergraduate;

public class UpdateUndergraduateUI {
private JFrame frame;
	
	private IUndergraduate undergraduateService;
	
	JButton btnHome;
	JButton btnAddUndergraduate;
	JButton btnAllUndergraduate;
	JButton btnUpdateUndergraduate;
	JButton btnRemoveUndergraduate;
	JButton btnFindUndergraduate;
	private JLabel lblUpdateUndergraduate;
	private JLabel lblUpdateUndergraduateId;
	private JLabel lblUpdateUndergraduateName;
	private JLabel lblUpdateHall_no;
	private JLabel lblUpdateAddress;
	private JTextField textFieldUpdateUndergraduateId;
	private JTextField textFieldUpdateUndergraduateName;
	private JTextField textFieldUpdateHall_no;
	private JTextField textFieldUpdateAddress;
	private JButton btnUpdate;

	/**
	 * Create the application.
	 */
	public UpdateUndergraduateUI(IUndergraduate undergraduateService) {
		this.undergraduateService = undergraduateService;
		initialize();
	
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new MainUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnAddUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AddUndergraduateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnAllUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AllUndergraduateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnUpdateUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new UpdateUndergraduateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnRemoveUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new RemoveUndergrauateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnFindUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new FindUndergraduateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);
		
		btnHome = new JButton("Home");
		btnHome.setBounds(10, 12, 140, 21);
		frame.getContentPane().add(btnHome);
		
		btnAddUndergraduate = new JButton("Add Undergraduate");
		btnAddUndergraduate.setBounds(10, 55, 140, 21);
		frame.getContentPane().add(btnAddUndergraduate);
		
		btnAllUndergraduate = new JButton("All Undergraduate");
		btnAllUndergraduate.setBounds(10, 98, 140, 21);
		frame.getContentPane().add(btnAllUndergraduate);
		
		btnUpdateUndergraduate = new JButton("Update Undergraduate");
		btnUpdateUndergraduate.setBounds(10, 144, 140, 21);
		frame.getContentPane().add(btnUpdateUndergraduate);
		
		btnRemoveUndergraduate = new JButton("Remove Undergraduate");
		btnRemoveUndergraduate.setBounds(10, 188, 140, 21);
		frame.getContentPane().add(btnRemoveUndergraduate);
		
		btnFindUndergraduate = new JButton("Find Undergraduate");
		btnFindUndergraduate.setBounds(10, 232, 140, 21);
		frame.getContentPane().add(btnFindUndergraduate);
		
		lblUpdateUndergraduate = new JLabel("Update Undergraduate");
		lblUpdateUndergraduate.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblUpdateUndergraduate.setBounds(248, 16, 124, 17);
		frame.getContentPane().add(lblUpdateUndergraduate);
		
		lblUpdateUndergraduateId = new JLabel("Undergraduate ID");
		lblUpdateUndergraduateId.setBounds(172, 59, 88, 13);
		frame.getContentPane().add(lblUpdateUndergraduateId);
		
		lblUpdateUndergraduateName = new JLabel("Undergraduate Name");
		lblUpdateUndergraduateName.setBounds(172, 102, 88, 13);
		frame.getContentPane().add(lblUpdateUndergraduateName);
		
		lblUpdateHall_no = new JLabel("Hall_no");
		lblUpdateHall_no.setBounds(172, 148, 88, 13);
		frame.getContentPane().add(lblUpdateHall_no);
		
		lblUpdateAddress = new JLabel("Address");
		lblUpdateAddress.setBounds(172, 192, 88, 13);
		frame.getContentPane().add(lblUpdateAddress);
		
		textFieldUpdateUndergraduateId = new JTextField();
		textFieldUpdateUndergraduateId.setBounds(235, 56, 117, 19);
		frame.getContentPane().add(textFieldUpdateUndergraduateId);
		textFieldUpdateUndergraduateId.setColumns(10);
		
		textFieldUpdateUndergraduateName = new JTextField();
		textFieldUpdateUndergraduateName.setBounds(270, 99, 117, 19);
		frame.getContentPane().add(textFieldUpdateUndergraduateName);
		textFieldUpdateUndergraduateName.setColumns(10);
		
		textFieldUpdateHall_no = new JTextField();
		textFieldUpdateHall_no.setBounds(270, 145, 117, 19);
		frame.getContentPane().add(textFieldUpdateHall_no);
		textFieldUpdateHall_no.setColumns(10);
		
		textFieldUpdateAddress = new JTextField();
		textFieldUpdateAddress.setBounds(270, 189, 117, 19);
		frame.getContentPane().add(textFieldUpdateAddress);
		textFieldUpdateAddress.setColumns(10);
		
		btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id, name, hall_no, address;
				id = textFieldUpdateUndergraduateId.getText().trim();
				name = textFieldUpdateUndergraduateName.getText().trim();
				hall_no = textFieldUpdateHall_no.getText().trim();
				address = textFieldUpdateAddress.getText().trim();
				
				if(id.isEmpty()) {
					JOptionPane.showMessageDialog( frame, "Please Add undergraduate ID number","Error",JOptionPane.WARNING_MESSAGE);
				}
				else if(name.isEmpty()) {
					JOptionPane.showMessageDialog( frame, "Please add undergraduate name","Error",JOptionPane.WARNING_MESSAGE);
				}
				else if(hall_no.isEmpty()) {
					JOptionPane.showMessageDialog( frame, "Please add hall_no","Error",JOptionPane.WARNING_MESSAGE);
				}
				else if(address.isEmpty()) {
					JOptionPane.showMessageDialog( frame, "Please add address","Error",JOptionPane.WARNING_MESSAGE);
				}
				else {
					try {
							Undergraduate undergraduate = new Undergraduate(id,name,hall_no,address);
							boolean isUndergraduate = undergraduateService.updateUndergraduateList( id,undergraduate);
							if(isUndergraduate) {
								textFieldUpdateUndergraduateId.setText("");
								textFieldUpdateUndergraduateName.setText("");
								textFieldUpdateHall_no.setText("");
								textFieldUpdateAddress.setText("");
								
								JOptionPane.showMessageDialog( frame, "Undergraduate update sucessfully","Success",JOptionPane.PLAIN_MESSAGE);
						}else {
							
							JOptionPane.showMessageDialog( frame, "Can not update Undergraduate","Error",JOptionPane.WARNING_MESSAGE);
						}

					}catch (Exception ex) {
						JOptionPane.showMessageDialog( frame, "Something went wrong","Error",JOptionPane.WARNING_MESSAGE);
						
					}
				}
			}
		});
		btnUpdate.setBounds(235, 232, 85, 21);
		frame.getContentPane().add(btnUpdate);
		
		JButton btnUpdateFind = new JButton("Find");
		btnUpdateFind.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = textFieldUpdateUndergraduateId.getText().trim();
				if(id.isEmpty()) {
					JOptionPane.showMessageDialog( frame, "Please Add undergraduate ID number","Error",JOptionPane.WARNING_MESSAGE);
				}
				else {

					try {
							
							Undergraduate undergraduate = undergraduateService.undergraduate_get_by_id(id);
							if(undergraduate != null) {
								textFieldUpdateUndergraduateName.setText(undergraduate.getName());
								textFieldUpdateHall_no.setText(undergraduate.getHall_no());
								textFieldUpdateAddress.setText(undergraduate.getAddress());
								
						}else {
//							textAreaRemove.setText("\n\nSorry, but nothing matched your search \nstudent. Please try again with different \nstudent ID.");
							JOptionPane.showMessageDialog( frame, "Can not find Undergraduate","Error",JOptionPane.WARNING_MESSAGE);
						}

					}catch (Exception ex) {
//						textAreaRemove.setText("Something went wrong");
						JOptionPane.showMessageDialog( frame, "Something went wrong","Error",JOptionPane.WARNING_MESSAGE);
						
					}
				}
			}
		});
		
		btnUpdateFind.setBounds(362, 55, 64, 21);
		frame.getContentPane().add(btnUpdateFind);
	}
}
