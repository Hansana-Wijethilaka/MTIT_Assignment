package undergraduatesubscriber;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import undergraduatepublisher.IUndergraduate;
import undergraduatepublisher.Undergraduate;



public class FindUndergraduateUI {
private JFrame frame;
	
	private IUndergraduate undergraduateService;
	
	JButton btnHome;
	JButton btnAddUndergraduate;
	JButton btnAllUndergraduates;
	JButton btnUpdateSUndergraduate;
	JButton btnRemoveUndergraduate;
	JButton btnFindUndergraduate;
	private JLabel lblFindUndergraduate;
	private JLabel lblEnterUndergraduateId;
	private JTextField textFieldSearch;
	private JButton btnSearchUndergraduate;
	private JTextArea textAreaSearcResult;

	/**
	 * Create the application.
	 */
	public FindUndergraduateUI(IUndergraduate undergraduateService) {
		this.undergraduateService = undergraduateService;
		initialize();
	
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new MainUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnAddUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AddUndergraduateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnAllUndergraduates.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AllUndergraduateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnUpdateSUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new UpdateUndergraduateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnRemoveUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new RemoveUndergrauateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnFindUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new FindUndergraduateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);
		
		btnHome = new JButton("Home");
		btnHome.setBounds(10, 12, 140, 21);
		frame.getContentPane().add(btnHome);
		
		btnAddUndergraduate = new JButton("Add Undergraduate");
		btnAddUndergraduate.setBounds(10, 55, 140, 21);
		frame.getContentPane().add(btnAddUndergraduate);
		
		btnAllUndergraduates = new JButton("All Undergraduates");
		btnAllUndergraduates.setBounds(10, 98, 140, 21);
		frame.getContentPane().add(btnAllUndergraduates);
		
		btnUpdateSUndergraduate = new JButton("Update Undergraduate");
		btnUpdateSUndergraduate.setBounds(10, 144, 140, 21);
		frame.getContentPane().add(btnUpdateSUndergraduate);
		
		btnRemoveUndergraduate = new JButton("Remove Undergraduate");
		btnRemoveUndergraduate.setBounds(10, 188, 140, 21);
		frame.getContentPane().add(btnRemoveUndergraduate);
		
		btnFindUndergraduate = new JButton("Find Undergraduate");
		btnFindUndergraduate.setBounds(10, 232, 140, 21);
		frame.getContentPane().add(btnFindUndergraduate);
		
		lblFindUndergraduate = new JLabel("Find Undergraduate");
		lblFindUndergraduate.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblFindUndergraduate.setBounds(248, 16, 124, 17);
		frame.getContentPane().add(lblFindUndergraduate);
		
		lblEnterUndergraduateId = new JLabel("Undergraduate ID");
		lblEnterUndergraduateId.setBounds(186, 46, 113, 13);
		frame.getContentPane().add(lblEnterUndergraduateId);
		
		textFieldSearch = new JTextField();
		textFieldSearch.setBounds(258, 43, 96, 19);
		frame.getContentPane().add(textFieldSearch);
		textFieldSearch.setColumns(10);
		
		btnSearchUndergraduate = new JButton("Find");
		btnSearchUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String id = textFieldSearch.getText().trim();
				if(id.isEmpty()) {

					JOptionPane.showMessageDialog( frame, "Please Add undergraduate ID number","Error",JOptionPane.WARNING_MESSAGE);
				}
				else {

					try {
							
							Undergraduate undergraduate = undergraduateService.undergraduate_get_by_id(id);
							if(undergraduate != null) {
								textAreaSearcResult.setText("Undergraduate ID : " + undergraduate.getId()  +
										"\nUndergraduate Name : " + undergraduate.getName() +
										"\nHall_no : " + undergraduate.getHall_no() +
										"\nUndergraduate Address : " + undergraduate.getAddress() + "\n" );
								
						}else {
							textAreaSearcResult.setText("\n\nSorry, but nothing matched your search \nundergraduate. Please try again with different \nundergraduate ID.");
							JOptionPane.showMessageDialog( frame, "Can not find Undergraduate","Error",JOptionPane.WARNING_MESSAGE);
						}

					}catch (Exception ex) {
						textAreaSearcResult.setText("Something went wrong");
						JOptionPane.showMessageDialog( frame, "Something went wrong","Error",JOptionPane.WARNING_MESSAGE);
						
					}
				
				}
			}
		});
		btnSearchUndergraduate.setBounds(366, 41, 60, 21);
		frame.getContentPane().add(btnSearchUndergraduate);
		
		textAreaSearcResult = new JTextArea();
		textAreaSearcResult.setBounds(186, 83, 240, 170);
		frame.getContentPane().add(textAreaSearcResult);
	}
}
