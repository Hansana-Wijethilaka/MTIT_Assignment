package undergraduatesubscriber;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import undergraduatepublisher.IUndergraduate;
import undergraduatepublisher.Undergraduate;



public class AddUndergraduateUI {

	private JFrame frame;

	private IUndergraduate undergraduateService;
	
	JButton btnHome;
	JButton btnAddUndergraduate;
	JButton btnAllUndergraduate;
	JButton btnUpdateUndergraduate;
	JButton btnRemoveUndergraduate;
	JButton btnFindUndergraduate;
	private JLabel lblAddUndergraduate;
	private JLabel lblUndergraduateId;
	private JTextField textFieldUndergraduateId;
	private JLabel lblUndergraduateName;
	private JTextField textFieldUndergraduateName;
	private JLabel lblHall_no;
	private JTextField textFieldHall_no;
	private JLabel lblAddress;
	private JTextField textFieldAddress;
	private JButton btnAdd;

	/**
	 * Create the application.
	 */
	public AddUndergraduateUI(IUndergraduate undergraduateService) {
		this.undergraduateService = undergraduateService;
		initialize();
	
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new MainUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnAddUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AddUndergraduateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnAllUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AllUndergraduateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnUpdateUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new UpdateUndergraduateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnRemoveUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new RemoveUndergrauateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnFindUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new FindUndergraduateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);
		
		btnHome = new JButton("Home");
		btnHome.setBounds(10, 12, 140, 21);
		frame.getContentPane().add(btnHome);
		
		btnAddUndergraduate = new JButton("Add Undergraduate");
		btnAddUndergraduate.setBounds(10, 55, 140, 21);
		frame.getContentPane().add(btnAddUndergraduate);
		
		btnAllUndergraduate = new JButton("All Undergraduate");
		btnAllUndergraduate.setBounds(10, 98, 140, 21);
		frame.getContentPane().add(btnAllUndergraduate);
		
		btnUpdateUndergraduate = new JButton("Update Undergraduate");
		btnUpdateUndergraduate.setBounds(10, 144, 140, 21);
		frame.getContentPane().add(btnUpdateUndergraduate);
		
		btnRemoveUndergraduate = new JButton("Remove Undergraduate");
		btnRemoveUndergraduate.setBounds(10, 188, 140, 21);
		frame.getContentPane().add(btnRemoveUndergraduate);
		
		btnFindUndergraduate = new JButton("Find Undergraduate");
		btnFindUndergraduate.setBounds(10, 232, 140, 21);
		frame.getContentPane().add(btnFindUndergraduate);
		
		lblAddUndergraduate = new JLabel("Add Undergraduate");
		lblAddUndergraduate.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblAddUndergraduate.setBounds(248, 16, 124, 17);
		frame.getContentPane().add(lblAddUndergraduate);
		
		lblUndergraduateId = new JLabel("Undergraduate ID");
		lblUndergraduateId.setBounds(198, 59, 96, 13);
		frame.getContentPane().add(lblUndergraduateId);
		
		textFieldUndergraduateId = new JTextField();
		textFieldUndergraduateId.setBounds(304, 56, 122, 19);
		frame.getContentPane().add(textFieldUndergraduateId);
		textFieldUndergraduateId.setColumns(10);
		
		lblUndergraduateName = new JLabel("Undergraduate Name");
		lblUndergraduateName.setBounds(198, 102, 81, 13);
		frame.getContentPane().add(lblUndergraduateName);
		
		textFieldUndergraduateName = new JTextField();
		textFieldUndergraduateName.setBounds(304, 99, 122, 19);
		frame.getContentPane().add(textFieldUndergraduateName);
		textFieldUndergraduateName.setColumns(10);
		
		lblHall_no = new JLabel("Hall_no");
		lblHall_no.setBounds(198, 148, 81, 13);
		frame.getContentPane().add(lblHall_no);
		
		textFieldHall_no = new JTextField();
		textFieldHall_no.setBounds(304, 145, 122, 19);
		frame.getContentPane().add(textFieldHall_no);
		textFieldHall_no.setColumns(10);
		
		lblAddress = new JLabel("Address");
		lblAddress.setBounds(198, 192, 81, 13);
		frame.getContentPane().add(lblAddress);
		
		textFieldAddress = new JTextField();
		textFieldAddress.setBounds(304, 189, 122, 19);
		frame.getContentPane().add(textFieldAddress);
		textFieldAddress.setColumns(10);
		
		btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String id, name, hall_no, address;
				id = textFieldUndergraduateId.getText().trim();
				name = textFieldUndergraduateName.getText().trim();
				hall_no = textFieldHall_no.getText().trim();
				address = textFieldAddress.getText().trim();
				
				if(id.isEmpty()) {
					JOptionPane.showMessageDialog( frame, "Please Add undergraduate ID number","Error",JOptionPane.WARNING_MESSAGE);
				}
				else if(name.isEmpty()) {
					JOptionPane.showMessageDialog( frame, "Please add undergraduate name","Error",JOptionPane.WARNING_MESSAGE);
				}
				else if(hall_no.isEmpty()) {
					JOptionPane.showMessageDialog( frame, "Please add hall_no","Error",JOptionPane.WARNING_MESSAGE);
				}
				else if(address.isEmpty()) {
					JOptionPane.showMessageDialog( frame, "Please add address","Error",JOptionPane.WARNING_MESSAGE);
				}
				else {
					try {
							Undergraduate undergraduate = new Undergraduate(id,name,hall_no,address);
							boolean isUndergraduate = undergraduateService.addUndergraduate(undergraduate);
							if(isUndergraduate) {
								textFieldUndergraduateId.setText("");
								textFieldUndergraduateName.setText("");
								textFieldHall_no.setText("");
								textFieldAddress.setText("");
								
								JOptionPane.showMessageDialog( frame, "Undergraduate add sucessfully","Success",JOptionPane.PLAIN_MESSAGE);
						}else {
							
							JOptionPane.showMessageDialog( frame, "Can not add Undergraduate","Error",JOptionPane.WARNING_MESSAGE);
						}

					}catch (Exception ex) {
						JOptionPane.showMessageDialog( frame, "Something went wrong","Error",JOptionPane.WARNING_MESSAGE);
						
					}
				}
				
				
			}
		});
		btnAdd.setBounds(266, 232, 85, 21);
		frame.getContentPane().add(btnAdd);
		
		
	}
}
