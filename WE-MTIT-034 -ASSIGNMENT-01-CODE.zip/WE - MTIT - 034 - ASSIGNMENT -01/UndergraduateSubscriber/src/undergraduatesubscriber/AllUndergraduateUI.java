package undergraduatesubscriber;


import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import undergraduatepublisher.IUndergraduate;
import undergraduatepublisher.Undergraduate;





public class AllUndergraduateUI {

	private JFrame frame;
	
	private IUndergraduate undergraduateService;
	
	JButton btnHome;
	JButton btnAddUndergraduate;
	JButton btnAllUndergraduate;
	JButton btnUpdateUndergraduate;
	JButton btnRemoveUndergraduate;
	JButton btnFindUndergraduate;
	JScrollPane scrollPane;
	private JLabel lblAllUndergraduate;
	private JTable table;

	/**
	 * Create the application.
	 */
	public AllUndergraduateUI(IUndergraduate undergraduateService) {
		this.undergraduateService = undergraduateService;
		initialize();
		
		ArrayList<Undergraduate> undergraduate = undergraduateService.get_all_undergraduate();
		if (!undergraduate.isEmpty()) {
		    List<Object[]> list = new ArrayList<Object[]>();
		    for (int i = 0; i < undergraduate.size(); i++) {
		        list.add(new Object[] { 
		        		undergraduate.get(i).getId(), 
		        		undergraduate.get(i).getName(),
		        		undergraduate.get(i).getHall_no(),
		        		undergraduate.get(i).getAddress()
		                              });

		    }
		    table.setModel(new DefaultTableModel(list.toArray(new Object[][] {}), 
		                        new String[] {"ID","Name", "Hall_no", "Address"}));
		}
	
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new MainUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnAddUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AddUndergraduateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnAllUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AllUndergraduateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnUpdateUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new UpdateUndergraduateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnRemoveUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new RemoveUndergrauateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnFindUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new FindUndergraduateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
	}


	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);
		
		btnHome = new JButton("Home");
		btnHome.setBounds(10, 12, 140, 21);
		frame.getContentPane().add(btnHome);
		
		btnAddUndergraduate = new JButton("Add Undergraduate");
		btnAddUndergraduate.setBounds(10, 55, 140, 21);
		frame.getContentPane().add(btnAddUndergraduate);
		
		btnAllUndergraduate= new JButton("All Undergraduate");
		btnAllUndergraduate.setBounds(10, 98, 140, 21);
		frame.getContentPane().add(btnAllUndergraduate);
		
		btnUpdateUndergraduate = new JButton("Update Undergraduate");
		btnUpdateUndergraduate.setBounds(10, 144, 140, 21);
		frame.getContentPane().add(btnUpdateUndergraduate);
		
		btnRemoveUndergraduate= new JButton("Remove Undergraduate");
		btnRemoveUndergraduate.setBounds(10, 188, 140, 21);
		frame.getContentPane().add(btnRemoveUndergraduate);
		
		btnFindUndergraduate = new JButton("Find Undergraduate");
		btnFindUndergraduate.setBounds(10, 232, 140, 21);
		frame.getContentPane().add(btnFindUndergraduate);
		
		
		lblAllUndergraduate = new JLabel("All Undergraduate");
		lblAllUndergraduate.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblAllUndergraduate.setBounds(248, 16, 124, 17);
		frame.getContentPane().add(lblAllUndergraduate);
		
		table = new JTable();
		scrollPane = new JScrollPane(table);
		scrollPane.setBounds(172, 58, 254, 184);
		frame.getContentPane().add(scrollPane);

	}
}

