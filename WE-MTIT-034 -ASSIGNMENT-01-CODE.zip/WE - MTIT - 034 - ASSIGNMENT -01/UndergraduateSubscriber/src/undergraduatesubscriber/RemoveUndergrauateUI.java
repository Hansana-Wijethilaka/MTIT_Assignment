package undergraduatesubscriber;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import undergraduatepublisher.IUndergraduate;
import undergraduatepublisher.Undergraduate;

public class RemoveUndergrauateUI {
private JFrame frame;
	
	private IUndergraduate undergraduateService;

	JButton btnHome;
	JButton btnAddUndergraduate;
	JButton btnAllUndergraduates;
	JButton btnUpdateUndergraduate;
	JButton btnRemoveUndergraduate;
	JButton btnFindUndergraduate;
	JButton btnRemove;
	
	private JLabel lblRemoveUndergraduate;
	private JLabel lblRemove;
	private JTextField textFieldRemove;
	private JButton btnSearch;
	private JTextArea textAreaRemove;
	private JButton btnDelete;

	/**
	 * Create the application.
	 */
	public RemoveUndergrauateUI(IUndergraduate undergraduateService) {
		this.undergraduateService = undergraduateService;
		initialize();
	
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new MainUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnAddUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AddUndergraduateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnAllUndergraduates.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AllUndergraduateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnUpdateUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new UpdateUndergraduateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnRemoveUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new RemoveUndergrauateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
		
		btnFindUndergraduate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new FindUndergraduateUI(undergraduateService);
				frame.setVisible(false);
			}
		});
	}
	/**
	 * Initialize the contents of the frame.
	 */

	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);
		
		btnHome = new JButton("Home");
		btnHome.setBounds(10, 12, 140, 21);
		frame.getContentPane().add(btnHome);
		
		btnAddUndergraduate = new JButton("Add Undergraduate");
		btnAddUndergraduate.setBounds(10, 55, 140, 21);
		frame.getContentPane().add(btnAddUndergraduate);
		
		btnAllUndergraduates = new JButton("All Undergraduates");
		btnAllUndergraduates.setBounds(10, 98, 140, 21);
		frame.getContentPane().add(btnAllUndergraduates);
		
		btnUpdateUndergraduate = new JButton("Update Undergraduate");
		btnUpdateUndergraduate.setBounds(10, 144, 140, 21);
		frame.getContentPane().add(btnUpdateUndergraduate);
		
		btnRemoveUndergraduate = new JButton("Remove Undergraduate");
		btnRemoveUndergraduate.setBounds(10, 188, 140, 21);
		frame.getContentPane().add(btnRemoveUndergraduate);
		
		btnFindUndergraduate = new JButton("Find Undergraduate");
		btnFindUndergraduate.setBounds(10, 232, 140, 21);
		frame.getContentPane().add(btnFindUndergraduate);
		
		lblRemoveUndergraduate = new JLabel("Remove Undergraduate");
		lblRemoveUndergraduate.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblRemoveUndergraduate.setBounds(248, 16, 124, 17);
		frame.getContentPane().add(lblRemoveUndergraduate);
		
		btnRemove = new JButton("Remove");
		frame.getContentPane().add(btnRemove);
		
		lblRemove = new JLabel("Undergraduate ID");
		lblRemove.setBounds(180, 45, 67, 13);
		frame.getContentPane().add(lblRemove);
		
		textFieldRemove = new JTextField();
		textFieldRemove.setBounds(245, 43, 96, 19);
		frame.getContentPane().add(textFieldRemove);
		textFieldRemove.setColumns(10);
		
		btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = textFieldRemove.getText().trim();
				if(id.isEmpty()) {
					JOptionPane.showMessageDialog( frame, "Please Add undergraduate ID number","Error",JOptionPane.WARNING_MESSAGE);
				}
				else {

					try {
							
							Undergraduate undergraduate = undergraduateService.undergraduate_get_by_id(id);
							if(undergraduate != null) {
								textAreaRemove.setText("Undergraduate ID : " + undergraduate.getId()  +
										"\nUndergraduate Name : " + undergraduate.getName() +
										"\nHall_no : " + undergraduate.getHall_no() +
										"\nUndergraduate Address : " + undergraduate.getAddress() + "\n" );
								
						}else {
							textAreaRemove.setText("\n\nSorry, but nothing matched your search \nstudent. Please try again with different \nstudent ID.");
							JOptionPane.showMessageDialog( frame, "Can not find Undergraduate","Error",JOptionPane.WARNING_MESSAGE);
						}

					}catch (Exception ex) {
						textAreaRemove.setText("Something went wrong");
						JOptionPane.showMessageDialog( frame, "Something went wrong","Error",JOptionPane.WARNING_MESSAGE);
						
					}
				}
			}
		});
		
		btnSearch.setBounds(351, 43, 75, 21);
		frame.getContentPane().add(btnSearch);
		
		textAreaRemove = new JTextArea();
		textAreaRemove.setBounds(180, 70, 246, 126);
		frame.getContentPane().add(textAreaRemove);
		
		btnDelete = new JButton("Remove Undergraduate");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = textFieldRemove.getText().trim();
				
				
				if(id.isEmpty()) {
					JOptionPane.showMessageDialog( frame, "Please Add undergraduate ID number","Error",JOptionPane.WARNING_MESSAGE);
				}
				else {
					try {
							
							boolean isUndergraduate = undergraduateService.deleteUndergraduate(id);
							if(isUndergraduate) {
								textFieldRemove.setText("");
								textAreaRemove.setText("\n\nUndergraduate deleted sucessfully");
								
								JOptionPane.showMessageDialog( frame, "Undergraduate deleted sucessfully","Success",JOptionPane.PLAIN_MESSAGE);
						}else {
							textAreaRemove.setText("\n\nCan not delete Undergraduate");
							JOptionPane.showMessageDialog( frame, "Can not delete Undergraduate","Error",JOptionPane.WARNING_MESSAGE);
						}

					}catch (Exception ex) {
						textAreaRemove.setText("\n\nSomething went wrong..!");
						JOptionPane.showMessageDialog( frame, "Something went wrong","Error",JOptionPane.WARNING_MESSAGE);
						
					}
				}

			}
		});
		btnDelete.setBounds(274, 219, 152, 21);
		frame.getContentPane().add(btnDelete);
	}
}
