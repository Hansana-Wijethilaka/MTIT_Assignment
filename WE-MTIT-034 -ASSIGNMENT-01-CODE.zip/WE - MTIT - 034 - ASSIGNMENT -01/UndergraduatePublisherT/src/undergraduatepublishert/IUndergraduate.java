package undergraduatepublishert;

import java.util.ArrayList;

public interface IUndergraduate {

	public boolean addUndergraduate(Undergraduate undergraduate);
	public boolean deleteUndergraduate(String id);
	public Undergraduate undergraduate_get_by_id(String id);
	public ArrayList<Undergraduate> get_all_undergraduate();
	public boolean updateUndergraduateList(String id, Undergraduate undergraduate);

}
