package undergraduatepublishert;

public class Undergraduate {

	private String id;
	private String name;
	private String hall_no;
	private String address;
	
	public Undergraduate(String id, String name, String hall_no, String address) {
		this.id = id;
		this.name = name;
		this.hall_no = hall_no;
		this.address = address;
	}

	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getHall_no() {
		return hall_no;
	}
	
	public void setHall_no(String hall_no) {
		this.hall_no = hall_no;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
}
