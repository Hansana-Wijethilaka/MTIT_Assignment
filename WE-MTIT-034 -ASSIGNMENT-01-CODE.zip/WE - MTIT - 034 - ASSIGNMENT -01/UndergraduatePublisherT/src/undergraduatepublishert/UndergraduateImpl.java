package undergraduatepublishert;

import java.util.ArrayList;

public class UndergraduateImpl implements IUndergraduate {

	private ArrayList<Undergraduate> undergraduateList = new ArrayList<Undergraduate>();
	
	@Override
	public boolean addUndergraduate(Undergraduate undergraduate) {
		undergraduateList.add(undergraduate);
		return true;
	}

	@Override
	public boolean deleteUndergraduate(String id) {
		if(undergraduateList.isEmpty()) {
			return false;
		}
		else {
			for(Undergraduate undergraduate : undergraduateList ) {
				if(undergraduate.getId().equals(id)) {
					undergraduateList.remove(undergraduate);
					return true;
				}
			}
			return false;
		}
	}

	@Override
	public Undergraduate undergraduate_get_by_id(String id) {
		if(undergraduateList.isEmpty()) {
			return null;
		}
		else {
			for(Undergraduate undergraduate : undergraduateList) {
				if(undergraduate.getId().equals(id)) {
					return undergraduate;
				}
			}
			return null;
		}
	}

	@Override
	public ArrayList<Undergraduate> get_all_undergraduate() {
		return undergraduateList;
	}

	@Override
	public boolean updateUndergraduateList(String id, Undergraduate undergraduate) {
		if(undergraduateList.isEmpty()) {
			return false;
		}
		else {
			int i = -1;
			for(Undergraduate obj : undergraduateList) {
				i =i + 1;
				if(obj.getId().equals(id)) {
					undergraduateList.set(i, new Undergraduate(undergraduate.getId(),undergraduate.getName(),undergraduate.getHall_no(),undergraduate.getAddress()));
					return true;
				}
			}
			return false;
		}
	}

}
