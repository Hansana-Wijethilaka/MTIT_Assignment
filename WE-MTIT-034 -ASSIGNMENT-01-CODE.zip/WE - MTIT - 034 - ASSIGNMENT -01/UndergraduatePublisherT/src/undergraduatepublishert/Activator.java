package undergraduatepublishert;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

public class Activator implements BundleActivator {

	private ServiceRegistration<?> serviceRegistration;


	public void start(BundleContext bundleContext) throws Exception {
		System.out.println("Undergraduate Publisher started");
		serviceRegistration = bundleContext.registerService(IUndergraduate.class.getName(), new UndergraduateImpl(), null);
	}

	public void stop(BundleContext bundleContext) throws Exception {
		System.out.println("Undergraduate Publisher stopped");
		serviceRegistration.unregister();
	}

}

