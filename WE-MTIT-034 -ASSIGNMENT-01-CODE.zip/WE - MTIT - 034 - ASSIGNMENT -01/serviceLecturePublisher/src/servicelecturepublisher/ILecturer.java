package servicelecturepublisher;

import java.util.ArrayList;



public interface ILecturer {
	
	public boolean addLecturer(Lecturer lecturer);
	public boolean deleteLecturer(String id);
	public Lecturer lecturer_get_by_id(String id);
	public ArrayList<Lecturer> get_all_lecturers();
	public boolean updateLecturer(String id, Lecturer lecturer);

}
