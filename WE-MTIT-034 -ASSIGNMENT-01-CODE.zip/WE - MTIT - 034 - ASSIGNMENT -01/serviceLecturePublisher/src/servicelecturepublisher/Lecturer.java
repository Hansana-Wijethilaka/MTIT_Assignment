package servicelecturepublisher;

public class Lecturer {
	
	private String id;
	private String name;
	private String course_name;
	private String address;
	
	public Lecturer(String id, String name, String course_name, String address) {
		this.id = id;
		this.name = name;
		this.course_name = course_name;
		this.address = address;
	}

	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getCourse_name() {
		return course_name;
	}
	
	public void setGrade(String course_name) {
		this.course_name = course_name;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}


}