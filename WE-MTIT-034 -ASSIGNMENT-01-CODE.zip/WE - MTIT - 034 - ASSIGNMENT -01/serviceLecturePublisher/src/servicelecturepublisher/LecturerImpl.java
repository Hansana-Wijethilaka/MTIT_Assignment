package servicelecturepublisher;

import java.util.ArrayList;



public class LecturerImpl implements ILecturer{

	private ArrayList<Lecturer> lecturerList = new ArrayList<>();

	@Override
	public boolean addLecturer(Lecturer lecturer) {
		lecturerList.add(lecturer);
		return true;
	}

	@Override
	public boolean deleteLecturer(String id) {
		if(lecturerList.isEmpty()) {
			return false;
		}
		else {
			for(Lecturer lecturer : lecturerList ) {
				if(lecturer.getId().equals(id)) {
					lecturerList.remove(lecturer);
					return true;
				}
			}
			return false;
		}
	}

	@Override
	public Lecturer lecturer_get_by_id(String id) {
		if(lecturerList.isEmpty()) {
			return null;
		}
		else {
			for(Lecturer lecturer : lecturerList) {
				if(lecturer.getId().equals(id)) {
					return lecturer;
				}
			}
			return null;
		}
	}

	@Override
	public ArrayList<Lecturer> get_all_lecturers() {
		return lecturerList;
	}
	


	@Override
	public boolean updateLecturer(String id, Lecturer lecturer) {
		if(lecturerList.isEmpty()) {
			return false;
		}
		else {
			int i = -1;
			for(Lecturer obj : lecturerList) {
				i =i + 1;
				if(obj.getId().equals(id)) {
					lecturerList.set(i, new Lecturer(lecturer.getId(),lecturer.getName(),lecturer.getCourse_name(),lecturer.getAddress()));
					return true;
				}
			}
			return false;
		}
	}
	
}