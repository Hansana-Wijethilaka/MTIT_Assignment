package servicecoursesubscriber;


import coursePublisher.ICourse;
//import org.omg.PortableServer.IdAssignmentPolicy;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;


public class Activator implements BundleActivator{


	private ServiceReference<?> courseServiceReference;
	

	private ICourse courseService;
	
	
	public void start(BundleContext bundleContext) throws Exception {
	
		courseServiceReference = bundleContext.getServiceReference(ICourse.class.getName());
		
		
		
		courseService = (ICourse) bundleContext.getService(courseServiceReference);
		
		
		System.out.println("Course subscriber is started");	
		MainUI frame = new MainUI( courseService);
		frame.setVisible(true);
//		MainUI frame = new MainUI(undergraduateService);
		
	}

	public void stop(BundleContext bundleContext) throws Exception {
		

		bundleContext.ungetService(courseServiceReference);
	
		
		System.out.println("Course subscriber is Stopped");	
	}

}
