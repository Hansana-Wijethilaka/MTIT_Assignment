package servicecoursesubscriber;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import coursePublisher.ICourse;


import javax.swing.BoxLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MainUI extends JFrame {

	private JPanel contentPane;
	private JButton btnUndergraduate;
	private JButton btnCourse;

	private ICourse courseService;
	

	
	public MainUI(ICourse courseService) {
		this.courseService = courseService;
		Initial();
	}

	
	
	public void Initial() {
		setTitle("course Panel");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 540, 379);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel menuPanel = new JPanel();
		menuPanel.setBounds(0, 0, 524, 340);
		contentPane.add(menuPanel);
		menuPanel.setLayout(null);
		
		
		JButton btnCourse = new JButton("Course");
		btnCourse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new CourseUI(courseService);
			}
		});
		btnCourse.setBounds(221, 125, 89, 23);
		menuPanel.add(btnCourse);
		
	}
	

}
