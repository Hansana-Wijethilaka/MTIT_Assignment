package servicecoursesubscriber;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import coursePublisher.Course;
import coursePublisher.ICourse;



public class AddCourseUI {
		
		private JFrame frame;

		private ICourse courseService;
		
		JButton btnHome;
		JButton btnAddCourse;
		JButton btnAllCourse;
		JButton btnUpdateCourse;
		JButton btnRemoveCourse;
		JButton btnFindCourse;
		private JLabel lblAddCourse;
		private JLabel lblCourseId;
		private JTextField textFieldCourseId;
		private JLabel lblCourseName;
		private JTextField textFieldCourseName;
		private JLabel lblHall_no;
		private JTextField textFieldHall_no;
		private JButton btnAdd;

		/**
		 * Create the application.
		 */
		public AddCourseUI(ICourse courseService) {
			this.courseService = courseService;
			initialize();
		
			btnHome.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					new MainUI(courseService);
					frame.setVisible(false);
				}
			});
			
			btnAddCourse.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					new AddCourseUI(courseService);
					frame.setVisible(false);
				}
			});
			
			btnAllCourse.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					new AllCourseUI(courseService);
					frame.setVisible(false);
				}
			});
			
			btnUpdateCourse.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					new UpdateCourseUI(courseService);
					frame.setVisible(false);
				}
			});
			
			btnRemoveCourse.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					new RemoveCourseUI(courseService);
					frame.setVisible(false);
				}
			});
			
			btnFindCourse.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					new FindCourseUI(courseService);
					frame.setVisible(false);
				}
			});
		}

		/**
		 * Initialize the contents of the frame.
		 */
		private void initialize() {
			frame = new JFrame();
			frame.setBounds(100, 100, 450, 300);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.getContentPane().setLayout(null);
			frame.setVisible(true);
			
			btnHome = new JButton("Home");
			btnHome.setBounds(10, 12, 140, 21);
			frame.getContentPane().add(btnHome);
			
			btnAddCourse = new JButton("Add Course");
			btnAddCourse.setBounds(10, 55, 140, 21);
			frame.getContentPane().add(btnAddCourse);
			
			btnAllCourse = new JButton("All Courses");
			btnAllCourse.setBounds(10, 98, 140, 21);
			frame.getContentPane().add(btnAllCourse);
			
			btnUpdateCourse = new JButton("Update Course");
			btnUpdateCourse.setBounds(10, 144, 140, 21);
			frame.getContentPane().add(btnUpdateCourse);
			
			btnRemoveCourse = new JButton("Remove Course");

			btnRemoveCourse.setBounds(10, 188, 140, 21);
			frame.getContentPane().add(btnRemoveCourse);
			
			btnFindCourse = new JButton("Find Course");
			btnFindCourse.setBounds(10, 232, 140, 21);
			frame.getContentPane().add(btnFindCourse);
			
			lblAddCourse = new JLabel("Add Course");
			lblAddCourse.setFont(new Font("Tahoma", Font.PLAIN, 13));
			lblAddCourse.setBounds(248, 16, 124, 17);
			frame.getContentPane().add(lblAddCourse);
			
			lblCourseId = new JLabel("Course ID");
			lblCourseId.setBounds(198, 59, 96, 13);
			frame.getContentPane().add(lblCourseId);
			
			textFieldCourseId = new JTextField();
			textFieldCourseId.setBounds(304, 56, 122, 19);
			frame.getContentPane().add(textFieldCourseId);
			textFieldCourseId.setColumns(10);
			
			lblCourseName = new JLabel("Course Name");
			lblCourseName.setBounds(198, 102, 81, 13);
			frame.getContentPane().add(lblCourseName);
			
			textFieldCourseName = new JTextField();
			textFieldCourseName.setBounds(304, 99, 122, 19);
			frame.getContentPane().add(textFieldCourseName);
			textFieldCourseName.setColumns(10);
			
			lblHall_no = new JLabel("Hall_no");
			lblHall_no.setBounds(198, 148, 81, 13);
			frame.getContentPane().add(lblHall_no);
			
			textFieldHall_no = new JTextField();
			textFieldHall_no.setBounds(304, 145, 122, 19);
			frame.getContentPane().add(textFieldHall_no);
			textFieldHall_no.setColumns(10);
			
			
			btnAdd = new JButton("Add");
			btnAdd.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					String id, name, hall_no;
					id = textFieldCourseId.getText().trim();
					name = textFieldCourseName.getText().trim();
					hall_no = textFieldHall_no.getText().trim();

					if(id.isEmpty()) {
						JOptionPane.showMessageDialog( frame, "Please Add Course ID number","Error",JOptionPane.WARNING_MESSAGE);
					}
					else if(name.isEmpty()) {
						JOptionPane.showMessageDialog( frame, "Please add Course name","Error",JOptionPane.WARNING_MESSAGE);
					}
					else if(hall_no.isEmpty()) {
						JOptionPane.showMessageDialog( frame, "Please add hall_no","Error",JOptionPane.WARNING_MESSAGE);
					}
					else {
						try {
								int cIid = Integer.parseInt(id);
								Course course = new Course(cIid,name,hall_no);
								boolean isCourse = courseService.addCourse(course);
								if(isCourse) {
									textFieldCourseId.setText("");
									textFieldCourseName.setText("");
									textFieldHall_no.setText("");
									
									JOptionPane.showMessageDialog( frame, "Course add sucessfully","Success",JOptionPane.PLAIN_MESSAGE);
							}else {
								
								JOptionPane.showMessageDialog( frame, "Can not add Course","Error",JOptionPane.WARNING_MESSAGE);
							}

						}catch (Exception ex) {
							JOptionPane.showMessageDialog( frame, "Something went wrong","Error",JOptionPane.WARNING_MESSAGE);
							
						}
					}
					
					
				}
			});
			btnAdd.setBounds(266, 232, 85, 21);
			frame.getContentPane().add(btnAdd);
		}
			

}