package servicecoursesubscriber;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

import coursePublisher.ICourse;

public class CourseUI {
		
		private JFrame frame;

		private ICourse courseService;
		
		
		JButton btnHome;
		JButton btnAddCourse;
		JButton btnAllCourse;
		JButton btnUpdateCourse;
		JButton btnRemoveCourse;
		JButton btnFindCourse;

		/**
		 * Create the application.
		 */
		public CourseUI(ICourse courseService) {
			this.courseService = courseService;
			initialize();
		
			btnHome.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					new MainUI(courseService);
					frame.setVisible(false);
				}
			});
			
			btnAddCourse.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					new AddCourseUI(courseService);
					frame.setVisible(false);
				}
			});
			
			btnAllCourse.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					new AllCourseUI(courseService);
					frame.setVisible(false);
				}
			});
			
			btnUpdateCourse.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					new UpdateCourseUI(courseService);
					frame.setVisible(false);
				}
			});
			
			btnRemoveCourse.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					new RemoveCourseUI(courseService);
					frame.setVisible(false);
				}
			});
			
			btnFindCourse.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					new FindCourseUI(courseService);
					frame.setVisible(false);
				}
			});
		}

		/**
		 * Initialize the contents of the frame.
		 */
		private void initialize() {
			frame = new JFrame();
			frame.setBounds(100, 100, 450, 300);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.getContentPane().setLayout(null);
			frame.setVisible(true);
			
			btnHome = new JButton("Home");
			btnHome.setBounds(10, 12, 140, 21);
			frame.getContentPane().add(btnHome);
			
			btnAddCourse = new JButton("Add Course");
			btnAddCourse.setBounds(10, 55, 140, 21);
			frame.getContentPane().add(btnAddCourse);
			
			btnAllCourse = new JButton("All Courses");
			btnAllCourse.setBounds(10, 98, 140, 21);
			frame.getContentPane().add(btnAllCourse);
			
			btnUpdateCourse = new JButton("Update Course");
			btnUpdateCourse.setBounds(10, 144, 140, 21);
			frame.getContentPane().add(btnUpdateCourse);
			
			btnRemoveCourse = new JButton("Remove Course");

			btnRemoveCourse.setBounds(10, 188, 140, 21);
			frame.getContentPane().add(btnRemoveCourse);
			
			btnFindCourse = new JButton("Find Course");
			btnFindCourse.setBounds(10, 232, 140, 21);
			frame.getContentPane().add(btnFindCourse);
			
			
		}
}