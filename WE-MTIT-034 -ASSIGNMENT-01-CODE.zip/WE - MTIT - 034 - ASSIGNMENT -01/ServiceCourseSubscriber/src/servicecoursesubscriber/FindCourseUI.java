package servicecoursesubscriber;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import coursePublisher.ICourse;
import coursePublisher.Course;

public class FindCourseUI {

	private JFrame frame;
	
	private ICourse courseService;
	
	JButton btnHome;
	JButton btnAddCourse;
	JButton btnAllCourse;
	JButton btnUpdateCourse;
	JButton btnRemoveCourse;
	JButton btnFindCourse;
	private JLabel lblFindCourse;
	private JLabel lblEnterCourseId;
	private JTextField textFieldSearch;
	private JButton btnSearchCourse;
	private JTextArea textAreaSearcResult;

	/**
	 * Create the application.
	 */
	public FindCourseUI(ICourse courseService) {
		this.courseService = courseService;
		initialize();
	
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new MainUI(courseService);
				frame.setVisible(false);
			}
		});
		
		btnAddCourse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AddCourseUI(courseService);
				frame.setVisible(false);
			}
		});
		
		btnAllCourse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AllCourseUI(courseService);
				frame.setVisible(false);
			}
		});
		
		btnUpdateCourse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new UpdateCourseUI(courseService);
				frame.setVisible(false);
			}
		});
		
		btnRemoveCourse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new RemoveCourseUI(courseService);
				frame.setVisible(false);
			}
		});
		
		btnFindCourse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new FindCourseUI(courseService);
				frame.setVisible(false);
			}
		});
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);
		
		btnHome = new JButton("Home");
		btnHome.setBounds(10, 12, 140, 21);
		frame.getContentPane().add(btnHome);
		
		btnAddCourse = new JButton("Add Course");
		btnAddCourse.setBounds(10, 55, 140, 21);
		frame.getContentPane().add(btnAddCourse);
		
		btnAllCourse = new JButton("All Courses");
		btnAllCourse.setBounds(10, 98, 140, 21);
		frame.getContentPane().add(btnAllCourse);
		
		btnUpdateCourse = new JButton("Update Course");
		btnUpdateCourse.setBounds(10, 144, 140, 21);
		frame.getContentPane().add(btnUpdateCourse);
		
		btnRemoveCourse = new JButton("Remove Course");

		btnRemoveCourse.setBounds(10, 188, 140, 21);
		frame.getContentPane().add(btnRemoveCourse);
		
		btnFindCourse = new JButton("Find Course");
		btnFindCourse.setBounds(10, 232, 140, 21);
		frame.getContentPane().add(btnFindCourse);
		
		lblFindCourse = new JLabel("Find Course");
		lblFindCourse.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblFindCourse.setBounds(248, 16, 124, 17);
		frame.getContentPane().add(lblFindCourse);
		
		lblEnterCourseId = new JLabel("Course ID");
		lblEnterCourseId.setBounds(186, 46, 113, 13);
		frame.getContentPane().add(lblEnterCourseId);
		
		textFieldSearch = new JTextField();
		textFieldSearch.setBounds(258, 43, 96, 19);
		frame.getContentPane().add(textFieldSearch);
		textFieldSearch.setColumns(10);
		
		btnSearchCourse = new JButton("Find");
		btnSearchCourse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String id = textFieldSearch.getText().trim();
				if(id.isEmpty()) {
					JOptionPane.showMessageDialog( frame, "Please Add Undergraduate ID number","Error",JOptionPane.WARNING_MESSAGE);
				}
				else {

					try {
							
							Course course = courseService.get_by_id(Integer.parseInt(id));
							if(course != null) {
								textAreaSearcResult.setText("Course ID : " + course.getId()  +
										"\nCourse Name : " + course.getCourse_name() +
										"\nHall_no: " + course.getHall_no() +"\n" );
								
								
								
								
								
						}else {
							textAreaSearcResult.setText("\n\nSorry, but nothing matched your search \ncourse. Please try again with different \nUndergraduate ID.");
							JOptionPane.showMessageDialog( frame, "Can not find Course","Error",JOptionPane.WARNING_MESSAGE);
						}

					}catch (Exception ex) {
						textAreaSearcResult.setText("Something went wrong");
						JOptionPane.showMessageDialog( frame, "Something went wrong","Error",JOptionPane.WARNING_MESSAGE);
						
					}
				
				}
			}
		});
		btnSearchCourse.setBounds(366, 41, 60, 21);
		frame.getContentPane().add(btnSearchCourse);
		
		textAreaSearcResult = new JTextArea();
		textAreaSearcResult.setBounds(186, 83, 240, 170);
		frame.getContentPane().add(textAreaSearcResult);
	}
}