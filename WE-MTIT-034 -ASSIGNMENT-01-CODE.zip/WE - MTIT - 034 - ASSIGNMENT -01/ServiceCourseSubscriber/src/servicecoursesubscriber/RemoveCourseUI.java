package servicecoursesubscriber;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import coursePublisher.ICourse;
import coursePublisher.Course;

public class RemoveCourseUI {

		private JFrame frame;
		
		private ICourse courseService;

		JButton btnHome;
		JButton btnAddCourse;
		JButton btnAllCourse;
		JButton btnUpdateCourse;
		JButton btnRemoveCourse;
		JButton btnFindCourse;
		JButton btnRemove;
		
		private JLabel lblRemoveCourse;
		private JLabel lblRemove;
		private JTextField textFieldRemove;
		private JButton btnSearch;
		private JTextArea textAreaRemove;
		private JButton btnDelete;

		/**
		 * Create the application.
		 */
		public RemoveCourseUI(ICourse courseService) {
			this.courseService = courseService;
			initialize();
		
			btnHome.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					new MainUI(courseService);
					frame.setVisible(false);
				}
			});
			
			btnAddCourse.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					new AddCourseUI(courseService);
					frame.setVisible(false);
				}
			});
			
			btnAllCourse.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					new AllCourseUI(courseService);
					frame.setVisible(false);
				}
			});
			
			btnUpdateCourse.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					new UpdateCourseUI(courseService);
					frame.setVisible(false);
				}
			});
			
			btnRemoveCourse.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					new RemoveCourseUI(courseService);
					frame.setVisible(false);
				}
			});
			
			btnFindCourse.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					new FindCourseUI(courseService);
					frame.setVisible(false);
				}
			});
		}
		/**
		 * Initialize the contents of the frame.
		 */

		private void initialize() {
			frame = new JFrame();
			frame.setBounds(100, 100, 450, 300);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.getContentPane().setLayout(null);
			frame.setVisible(true);
			
			btnHome = new JButton("Home");
			btnHome.setBounds(10, 12, 140, 21);
			frame.getContentPane().add(btnHome);
			
			btnAddCourse = new JButton("Add Course");
			btnAddCourse.setBounds(10, 55, 140, 21);
			frame.getContentPane().add(btnAddCourse);
			
			btnAllCourse = new JButton("All Courses");
			btnAllCourse.setBounds(10, 98, 140, 21);
			frame.getContentPane().add(btnAllCourse);
			
			btnUpdateCourse = new JButton("Update Course");
			btnUpdateCourse.setBounds(10, 144, 140, 21);
			frame.getContentPane().add(btnUpdateCourse);
			
			btnRemoveCourse = new JButton("Remove Course");
			btnRemoveCourse.setBounds(10, 188, 140, 21);
			frame.getContentPane().add(btnRemoveCourse);
			
			btnFindCourse = new JButton("Find Course");
			btnFindCourse.setBounds(10, 232, 140, 21);
			frame.getContentPane().add(btnFindCourse);
			
			lblRemoveCourse = new JLabel("Remove Course");
			lblRemoveCourse.setFont(new Font("Tahoma", Font.PLAIN, 13));
			lblRemoveCourse.setBounds(248, 16, 124, 17);
			frame.getContentPane().add(lblRemoveCourse);
			
			btnRemove = new JButton("Remove");
			frame.getContentPane().add(btnRemove);
			
			lblRemove = new JLabel("Course ID");
			lblRemove.setBounds(180, 45, 67, 13);
			frame.getContentPane().add(lblRemove);
			
			textFieldRemove = new JTextField();
			textFieldRemove.setBounds(245, 43, 96, 19);
			frame.getContentPane().add(textFieldRemove);
			textFieldRemove.setColumns(10);
			
			btnSearch = new JButton("Search");
			btnSearch.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String id = textFieldRemove.getText().trim();
					if(id.isEmpty()) {
						JOptionPane.showMessageDialog( frame, "Please Add Undergraduate ID number","Error",JOptionPane.WARNING_MESSAGE);
					}
					else {

						try {
								
								Course course = courseService.get_by_id(Integer.parseInt(id));
								if(course != null) {
									textAreaRemove.setText("course ID : " + course.getId()  +
											"\nCourse Name : " + course.getCourse_name() +
											"\nGrade : " + course.getHall_no());
									
							}else {
								textAreaRemove.setText("\n\nSorry, but nothing matched your search \ncourse. Please try again with different \nsUndergraduate ID.");
								JOptionPane.showMessageDialog( frame, "Can not find Subject","Error",JOptionPane.WARNING_MESSAGE);
							}

						}catch (Exception ex) {
							textAreaRemove.setText("Something went wrong");
							JOptionPane.showMessageDialog( frame, "Something went wrong","Error",JOptionPane.WARNING_MESSAGE);
							
						}
					}
				}
			});
			
			btnSearch.setBounds(351, 43, 75, 21);
			frame.getContentPane().add(btnSearch);
			
			textAreaRemove = new JTextArea();
			textAreaRemove.setBounds(180, 70, 246, 126);
			frame.getContentPane().add(textAreaRemove);
			
			btnDelete = new JButton("RemoveCourse");
			btnDelete.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String id = textFieldRemove.getText().trim();
					
					
					if(id.isEmpty()) {
						JOptionPane.showMessageDialog( frame, "Please Add course ID number","Error",JOptionPane.WARNING_MESSAGE);
					}
					else {
						try {
								
								boolean isCourse = courseService.deleteCourse(Integer.parseInt(id));
								if(isCourse) {
									textFieldRemove.setText("");
									textAreaRemove.setText("\n\nCourse deleted sucessfully");
									
									JOptionPane.showMessageDialog( frame, "Course deleted sucessfully","Success",JOptionPane.PLAIN_MESSAGE);
							}else {
								textAreaRemove.setText("\n\nCan not delete Course");
								JOptionPane.showMessageDialog( frame, "Can not delete Course","Error",JOptionPane.WARNING_MESSAGE);
							}

						}catch (Exception ex) {
							textAreaRemove.setText("\n\nSomething went wrong..!");
							JOptionPane.showMessageDialog( frame, "Something went wrong","Error",JOptionPane.WARNING_MESSAGE);
							
						}
					}

				}
			});
			btnDelete.setBounds(274, 219, 152, 21);
			frame.getContentPane().add(btnDelete);
		}

}