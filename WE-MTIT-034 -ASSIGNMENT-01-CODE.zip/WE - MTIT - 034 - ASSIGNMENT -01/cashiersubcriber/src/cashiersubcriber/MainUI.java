package cashiersubcriber;


import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import cashierpublisher.ICashier;
import cashierpublisher.Cashier;

public class MainUI extends JFrame{
	
	private JPanel contentPane1;
	private JButton btnCashier;
	private JButton btnCourse;

	private ICashier cashierService;
	
	
	
	
	
	public MainUI(ICashier cashierService) {
		this.cashierService = cashierService;
		Initial();
	}


	public void Initial() {
		setTitle("Cashier Panel");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 540, 379);
		contentPane1 = new JPanel();
		contentPane1.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane1);
		contentPane1.setLayout(null);
		
		JPanel menuPanel = new JPanel();
		menuPanel.setBounds(0, 0, 524, 320);
		contentPane1.add(menuPanel);
		menuPanel.setLayout(null);
		
		JButton btnCashier = new JButton("Cashier");
		btnCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new CashierUI(cashierService);
			}
		});
		btnCashier.setBounds(221, 52, 89, 23);
		menuPanel.add(btnCashier);
		
		
	}

}

