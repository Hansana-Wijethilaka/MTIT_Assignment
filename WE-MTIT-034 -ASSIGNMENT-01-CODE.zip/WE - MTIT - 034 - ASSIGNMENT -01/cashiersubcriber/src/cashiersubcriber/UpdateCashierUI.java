package cashiersubcriber;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import cashierpublisher.ICashier;
import cashierpublisher.Cashier;

public class UpdateCashierUI {
private JFrame frame;
	
	private ICashier cashierService;
	
	JButton btnHome;
	JButton btnAddCashier;
	JButton btnAllCashier;
	JButton btnUpdateCashier;
	JButton btnRemoveCashier;
	JButton btnFindCashier;
	private JLabel lblUpdateCashier;
	private JLabel lblUpdateCashierId;
	private JLabel lblUpdateCashierName;
	private JLabel lblUpdateAge;
	private JLabel lblUpdateAddress;
	private JTextField textFieldUpdateCashierId;
	private JTextField textFieldUpdateCashierName;
	private JTextField textFieldUpdateAge;
	private JTextField textFieldUpdateAddress;
	private JButton btnUpdate;

	/**
	 * Create the application.
	 */
	public UpdateCashierUI(ICashier cashierService) {
		this.cashierService = cashierService;
		initialize();
	
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new MainUI(cashierService);
				frame.setVisible(false);
			}
		});
		
		btnAddCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AddCashierUI(cashierService);
				frame.setVisible(false);
			}
		});
		
		btnAllCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AllCashierUI(cashierService);
				frame.setVisible(false);
			}
		});
		
		btnUpdateCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new UpdateCashierUI(cashierService);
				frame.setVisible(false);
			}
		});
		
		btnRemoveCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new RemoveCashierUI(cashierService);
				frame.setVisible(false);
			}
		});
		
		btnFindCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new FindCashierUI(cashierService);
				frame.setVisible(false);
			}
		});
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);
		
		btnHome = new JButton("Home");
		btnHome.setBounds(10, 12, 140, 21);
		frame.getContentPane().add(btnHome);
		
		btnAddCashier = new JButton("Add Cashier");
		btnAddCashier.setBounds(10, 55, 140, 21);
		frame.getContentPane().add(btnAddCashier);
		
		btnAllCashier = new JButton("All Cashier");
		btnAllCashier.setBounds(10, 98, 140, 21);
		frame.getContentPane().add(btnAllCashier);
		
		btnUpdateCashier = new JButton("Update Cashier");
		btnUpdateCashier.setBounds(10, 144, 140, 21);
		frame.getContentPane().add(btnUpdateCashier);
		
		btnRemoveCashier = new JButton("Remove Cashier");
		btnRemoveCashier.setBounds(10, 188, 140, 21);
		frame.getContentPane().add(btnRemoveCashier);
		
		btnFindCashier = new JButton("Find Cashier");
		btnFindCashier.setBounds(10, 232, 140, 21);
		frame.getContentPane().add(btnFindCashier);
		
		lblUpdateCashier = new JLabel("Update Cashier");
		lblUpdateCashier.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblUpdateCashier.setBounds(248, 16, 124, 17);
		frame.getContentPane().add(lblUpdateCashier);
		
		lblUpdateCashierId = new JLabel("Cashier ID");
		lblUpdateCashierId.setBounds(172, 59, 88, 13);
		frame.getContentPane().add(lblUpdateCashierId);
		
		lblUpdateCashierName = new JLabel("Cashier Name");
		lblUpdateCashierName.setBounds(172, 102, 88, 13);
		frame.getContentPane().add(lblUpdateCashierName);
		
		lblUpdateAge = new JLabel("Age");
		lblUpdateAge.setBounds(172, 148, 88, 13);
		frame.getContentPane().add(lblUpdateAge);
		
		lblUpdateAddress = new JLabel("Address");
		lblUpdateAddress.setBounds(172, 192, 88, 13);
		frame.getContentPane().add(lblUpdateAddress);
		
		textFieldUpdateCashierId = new JTextField();
		textFieldUpdateCashierId.setBounds(235, 56, 117, 19);
		frame.getContentPane().add(textFieldUpdateCashierId);
		textFieldUpdateCashierId.setColumns(10);
		
		textFieldUpdateCashierName = new JTextField();
		textFieldUpdateCashierName.setBounds(270, 99, 117, 19);
		frame.getContentPane().add(textFieldUpdateCashierName);
		textFieldUpdateCashierName.setColumns(10);
		
		textFieldUpdateAge = new JTextField();
		textFieldUpdateAge.setBounds(270, 145, 117, 19);
		frame.getContentPane().add(textFieldUpdateAge);
		textFieldUpdateAge.setColumns(10);
		
		textFieldUpdateAddress = new JTextField();
		textFieldUpdateAddress.setBounds(270, 189, 117, 19);
		frame.getContentPane().add(textFieldUpdateAddress);
		textFieldUpdateAddress.setColumns(10);
		
		btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id, name, age, Address;
				id = textFieldUpdateCashierId.getText().trim();
				name = textFieldUpdateCashierName.getText().trim();
				age = textFieldUpdateAge.getText().trim();
				Address = textFieldUpdateAddress.getText().trim();
				
				if(id.isEmpty()) {
					JOptionPane.showMessageDialog( frame, "Please Add Cashier ID number","Error",JOptionPane.WARNING_MESSAGE);
				}
				else if(name.isEmpty()) {
					JOptionPane.showMessageDialog( frame, "Please add cashier name","Error",JOptionPane.WARNING_MESSAGE);
				}
				else if(age.isEmpty()) {
					JOptionPane.showMessageDialog( frame, "Please add Age","Error",JOptionPane.WARNING_MESSAGE);
				}
				else if(Address.isEmpty()) {
					JOptionPane.showMessageDialog( frame, "Please add Address","Error",JOptionPane.WARNING_MESSAGE);
				}
				else {
					try {
							Cashier cashier = new Cashier(id,name,age,Address);
							boolean isCashier = cashierService.updateCashierList( id,cashier);
							if(isCashier) {
								textFieldUpdateCashierId.setText("");
								textFieldUpdateCashierName.setText("");
								textFieldUpdateAge.setText("");
								textFieldUpdateAddress.setText("");
								
								JOptionPane.showMessageDialog( frame, "Cashier update sucessfully","Success",JOptionPane.PLAIN_MESSAGE);
						}else {
							
							JOptionPane.showMessageDialog( frame, "Can not update Undergraduate","Error",JOptionPane.WARNING_MESSAGE);
						}

					}catch (Exception ex) {
						JOptionPane.showMessageDialog( frame, "Something went wrong","Error",JOptionPane.WARNING_MESSAGE);
						
					}
				}
			}
		});
		btnUpdate.setBounds(235, 232, 85, 21);
		frame.getContentPane().add(btnUpdate);
		
		JButton btnUpdateFind = new JButton("Find");
		btnUpdateFind.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = textFieldUpdateCashierId.getText().trim();
				if(id.isEmpty()) {
					JOptionPane.showMessageDialog( frame, "Please Add cashier ID number","Error",JOptionPane.WARNING_MESSAGE);
				}
				else {

					try {
							
							Cashier cashier = cashierService.cashier_get_by_id(id);
							if(cashier != null) {
								textFieldUpdateCashierName.setText(cashier.getName());
								textFieldUpdateAge.setText(cashier.getAge());
								textFieldUpdateAddress.setText(cashier.getAddress());
								
						}else {
  //							textAreaRemove.setText("\n\nSorry, but nothing matched your search \nstudent. Please try again with different \nstudent ID.");
							JOptionPane.showMessageDialog( frame, "Can not find Undergraduate","Error",JOptionPane.WARNING_MESSAGE);
						}

					}catch (Exception ex) {
//						textAreaRemove.setText("Something went wrong");
						JOptionPane.showMessageDialog( frame, "Something went wrong","Error",JOptionPane.WARNING_MESSAGE);
						
					}
				}
			}
		});
		
		btnUpdateFind.setBounds(362, 55, 64, 21);
		frame.getContentPane().add(btnUpdateFind);
	}
}
