package cashiersubcriber;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import cashierpublisher.Cashier;
import cashierpublisher.ICashier;




public class FindCashierUI {
private JFrame frame;
	
	private ICashier cashierService;
	
	JButton btnHome;
	JButton btnAddcashier;
	JButton btnAllcashiers;
	JButton btnUpdateScashier;
	JButton btnRemovecashier;
	JButton btnFindcashier;
	private JLabel lblFindcashier;
	private JLabel lblEntercashierId;
	private JTextField textFieldSearch;
	private JButton btnSearchcashier;
	private JTextArea textAreaSearcResult;

	/**
	 * Create the application.
	 */
	public FindCashierUI(ICashier cashierService) {
		this.cashierService = cashierService;
		initialize();
	
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new MainUI(cashierService);
				frame.setVisible(false);
			}
		});
		
		btnAddcashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AddCashierUI(cashierService);
				frame.setVisible(false);
			}
		});
		
		btnAllcashiers.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AllCashierUI(cashierService);
				frame.setVisible(false);
			}
		});
		
		btnUpdateScashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new UpdateCashierUI(cashierService);
				frame.setVisible(false);
			}
		});
		
		btnRemovecashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new RemoveCashierUI(cashierService);
				frame.setVisible(false);
			}
		});
		
		btnFindcashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new FindCashierUI(cashierService);
				frame.setVisible(false);
			}
		});
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);
		
		btnHome = new JButton("Home");
		btnHome.setBounds(10, 12, 140, 21);
		frame.getContentPane().add(btnHome);
		
		btnAddcashier = new JButton("Add Cashier");
		btnAddcashier.setBounds(10, 55, 140, 21);
		frame.getContentPane().add(btnAddcashier);
		
		btnAllcashiers = new JButton("All Cashier");
		btnAllcashiers.setBounds(10, 98, 140, 21);
		frame.getContentPane().add(btnAllcashiers);
		
		btnUpdateScashier = new JButton("Update Cashier");
		btnUpdateScashier.setBounds(10, 144, 140, 21);
		frame.getContentPane().add(btnUpdateScashier);
		
		btnRemovecashier = new JButton("Remove Cashier");
		btnRemovecashier.setBounds(10, 188, 140, 21);
		frame.getContentPane().add(btnRemovecashier);
		
		btnFindcashier = new JButton("Find Cashier");
		btnFindcashier.setBounds(10, 232, 140, 21);
		frame.getContentPane().add(btnFindcashier);
		
		lblFindcashier = new JLabel("Find Cashier");
		lblFindcashier.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblFindcashier.setBounds(248, 16, 124, 17);
		frame.getContentPane().add(lblFindcashier);
		
		lblEntercashierId = new JLabel("Cashier ID");
		lblEntercashierId.setBounds(186, 46, 113, 13);
		frame.getContentPane().add(lblEntercashierId);
		
		textFieldSearch = new JTextField();
		textFieldSearch.setBounds(258, 43, 96, 19);
		frame.getContentPane().add(textFieldSearch);
		textFieldSearch.setColumns(10);
		
		btnSearchcashier = new JButton("Find");
		btnSearchcashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String id = textFieldSearch.getText().trim();
				if(id.isEmpty()) {

					JOptionPane.showMessageDialog( frame, "Please Add Cashier ID number","Error",JOptionPane.WARNING_MESSAGE);
				}
				else {

					try {
							
							Cashier cashier = cashierService.cashier_get_by_id(id);
							if(cashier != null) {
								textAreaSearcResult.setText("cashier ID : " + cashier.getId()  +
										"\ncashier Name : " + cashier.getName() +
										"\nAge : " + cashier.getAge() +
										"\ncashier Address : " + cashier.getAddress() + "\n" );
								
						}else {
							textAreaSearcResult.setText("\n\nSorry, but nothing matched your search \ncashier. Please try again with different \ncashier ID.");
							JOptionPane.showMessageDialog( frame, "Can not find cashier","Error",JOptionPane.WARNING_MESSAGE);
						}

					}catch (Exception ex) {
						textAreaSearcResult.setText("Something went wrong");
						JOptionPane.showMessageDialog( frame, "Something went wrong","Error",JOptionPane.WARNING_MESSAGE);
						
					}
				
				}
			}
		});
		btnSearchcashier.setBounds(366, 41, 60, 21);
		frame.getContentPane().add(btnSearchcashier);
		
		textAreaSearcResult = new JTextArea();
		textAreaSearcResult.setBounds(186, 83, 240, 170);
		frame.getContentPane().add(textAreaSearcResult);
	}
}
