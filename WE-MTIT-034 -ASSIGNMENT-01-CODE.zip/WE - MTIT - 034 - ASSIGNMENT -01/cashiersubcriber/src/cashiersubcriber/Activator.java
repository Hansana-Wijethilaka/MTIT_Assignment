package cashiersubcriber;

import cashierpublisher.ICashier;
import java.util.Hashtable;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceEvent;
import org.osgi.framework.ServiceListener;
import org.osgi.framework.ServiceReference;
import org.osgi.util.tracker.ServiceTracker;




//import org.omg.PortableServer.IdAssignmentPolicy;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;





public class Activator implements BundleActivator{

	private ServiceReference<?> cashierReference;
	
	private ICashier cashierService;

	
	public void start(BundleContext bundleContext) throws Exception {
		
		cashierReference = bundleContext.getServiceReference(ICashier.class.getName());
	
		
		cashierService = (ICashier) bundleContext.getService(cashierReference);
	
		
		System.out.println("Cashier subscriber is started");	
		MainUI frame = new MainUI(cashierService);
		frame.setVisible(true);

		
	}

	public void stop(BundleContext bundleContext) throws Exception {
		
		bundleContext.ungetService(cashierReference);
		
		System.out.println("Cashier subscriber is Stopped");	
	}

}
