package cashiersubcriber;


import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import cashierpublisher.ICashier;
import cashierpublisher.Cashier;





public class AllCashierUI {

	private JFrame frame;
	
	private ICashier cashierservice;
	
	JButton btnHome;
	JButton btnAddCashier;
	JButton btnAllCashier;
	JButton btnUpdateCashier;
	JButton btnRemoveCashier;
	JButton btnFindCashier;
	JScrollPane scrollPane;
	private JLabel lblAllCashier;
	private JTable table;

	/**
	 * Create the application.
	 */
	public AllCashierUI(ICashier cashierservice) {
		this.cashierservice = cashierservice;
		initialize();
		
		ArrayList<Cashier> cashier = cashierservice.get_all_cashier();
		if (!cashier.isEmpty()) {
		    List<Object[]> list = new ArrayList<Object[]>();
		    for (int i = 0; i < cashier.size(); i++) {
		        list.add(new Object[] { 
		        		cashier.get(i).getId(), 
		        		cashier.get(i).getName(),
		        		cashier.get(i).getAge(),
		        		cashier.get(i).getAddress()
		                              });

		    }
		    table.setModel(new DefaultTableModel(list.toArray(new Object[][] {}), 
		                        new String[] {"ID","Name", "Age", "Address"}));
		}
	
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new MainUI(cashierservice);
				frame.setVisible(false);
			}
		});
		
		btnAddCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AddCashierUI(cashierservice);
				frame.setVisible(false);
			}
		});
		
		btnAllCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AllCashierUI(cashierservice);
				frame.setVisible(false);
			}
		});
		
		btnUpdateCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new UpdateCashierUI(cashierservice);
				frame.setVisible(false);
			}
		});
		
		btnRemoveCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new RemoveCashierUI(cashierservice);
				frame.setVisible(false);
			}
		});
		
		btnFindCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new FindCashierUI(cashierservice);
				frame.setVisible(false);
			}
		});
	}


	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);
		
		btnHome = new JButton("Home");
		btnHome.setBounds(10, 12, 140, 21);
		frame.getContentPane().add(btnHome);
		
		btnAddCashier = new JButton("Add Cashier");
		btnAddCashier.setBounds(10, 55, 140, 21);
		frame.getContentPane().add(btnAddCashier);
		
		btnAllCashier= new JButton("All Cashier");
		btnAllCashier.setBounds(10, 98, 140, 21);
		frame.getContentPane().add(btnAllCashier);
		
		btnUpdateCashier = new JButton("Update Cashier");
		btnUpdateCashier.setBounds(10, 144, 140, 21);
		frame.getContentPane().add(btnUpdateCashier);
		
		btnRemoveCashier= new JButton("Remove cashier");
		btnRemoveCashier.setBounds(10, 188, 140, 21);
		frame.getContentPane().add(btnRemoveCashier);
		
		btnFindCashier = new JButton("Find Cashier");
		btnFindCashier.setBounds(10, 232, 140, 21);
		frame.getContentPane().add(btnFindCashier);
		
		
		lblAllCashier = new JLabel("All Cashier");
		lblAllCashier.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblAllCashier.setBounds(248, 16, 124, 17);
		frame.getContentPane().add(lblAllCashier);
		
		table = new JTable();
		scrollPane = new JScrollPane(table);
		scrollPane.setBounds(172, 58, 254, 184);
		frame.getContentPane().add(scrollPane);

	}
}

