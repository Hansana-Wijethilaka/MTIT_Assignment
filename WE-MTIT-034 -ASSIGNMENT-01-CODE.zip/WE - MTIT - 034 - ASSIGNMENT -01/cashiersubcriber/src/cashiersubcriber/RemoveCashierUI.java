package cashiersubcriber;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import cashierpublisher.Cashier;
import cashierpublisher.ICashier;


public class RemoveCashierUI {
private JFrame frame;
	
	private ICashier cashierService;

	JButton btnHome;
	JButton btnAddCashier;
	JButton btnAllCashier;
	JButton btnUpdateCashier;
	JButton btnRemoveCashier;
	JButton btnFindCashier;
	JButton btnRemove;
	
	private JLabel lblRemoveCashier;
	private JLabel lblRemove;
	private JTextField textFieldRemove;
	private JButton btnSearch;
	private JTextArea textAreaRemove;
	private JButton btnDelete;

	/**
	 * Create the application.
	 */
	public RemoveCashierUI(ICashier cashierService) {
		this.cashierService = cashierService;
		initialize();
	
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new MainUI(cashierService);
				frame.setVisible(false);
			}
		});
		
		btnAddCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AddCashierUI(cashierService);
				frame.setVisible(false);
			}
		});
		
		btnAllCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AllCashierUI(cashierService);
				frame.setVisible(false);
			}
		});
		
		btnUpdateCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new UpdateCashierUI(cashierService);
				frame.setVisible(false);
			}
		});
		
		btnRemoveCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new RemoveCashierUI(cashierService);
				frame.setVisible(false);
			}
		});
		
		btnFindCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new FindCashierUI(cashierService);
				frame.setVisible(false);
			}
		});
	}
	/**
	 * Initialize the contents of the frame.
	 */

	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);
		
		btnHome = new JButton("Home");
		btnHome.setBounds(10, 12, 140, 21);
		frame.getContentPane().add(btnHome);
		
		btnAddCashier = new JButton("Add Cashier");
		btnAddCashier.setBounds(10, 55, 140, 21);
		frame.getContentPane().add(btnAddCashier);
		
		btnAllCashier = new JButton("All Cashiers");
		btnAllCashier.setBounds(10, 98, 140, 21);
		frame.getContentPane().add(btnAllCashier);
		
		btnUpdateCashier = new JButton("Update Cashier");
		btnUpdateCashier.setBounds(10, 144, 140, 21);
		frame.getContentPane().add(btnUpdateCashier);
		
		btnRemoveCashier = new JButton("Remove Cashier");
		btnRemoveCashier.setBounds(10, 188, 140, 21);
		frame.getContentPane().add(btnRemoveCashier);
		
		btnFindCashier = new JButton("Find Cashier");
		btnFindCashier.setBounds(10, 232, 140, 21);
		frame.getContentPane().add(btnFindCashier);
		
		lblRemoveCashier = new JLabel("Remove Cashier");
		lblRemoveCashier.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblRemoveCashier.setBounds(248, 16, 124, 17);
		frame.getContentPane().add(lblRemoveCashier);
		
		btnRemove = new JButton("Remove");
		frame.getContentPane().add(btnRemove);
		
		lblRemove = new JLabel("Cashier ID");
		lblRemove.setBounds(180, 45, 67, 13);
		frame.getContentPane().add(lblRemove);
		
		textFieldRemove = new JTextField();
		textFieldRemove.setBounds(245, 43, 96, 19);
		frame.getContentPane().add(textFieldRemove);
		textFieldRemove.setColumns(10);
		
		btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = textFieldRemove.getText().trim();
				if(id.isEmpty()) {
					JOptionPane.showMessageDialog( frame, "Please Add Cashier ID number","Error",JOptionPane.WARNING_MESSAGE);
				}
				else {

					try {
							
							Cashier cashier = cashierService.cashier_get_by_id(id);
							if(cashier != null) {
								textAreaRemove.setText("Cashier ID : " + cashier.getId()  +
										"\nCashier Name : " + cashier.getName() +
										"\nAge : " + cashier.getAge() +
										"\nAddress : " + cashier.getAddress() + "\n" );
								
						}else {
							textAreaRemove.setText("\n\nSorry, but nothing matched your search \nstudent. Please try again with different \nstudent ID.");
							JOptionPane.showMessageDialog( frame, "Can not find Cashier","Error",JOptionPane.WARNING_MESSAGE);
						}

					}catch (Exception ex) {
						textAreaRemove.setText("Something went wrong");
						JOptionPane.showMessageDialog( frame, "Something went wrong","Error",JOptionPane.WARNING_MESSAGE);
						
					}
				}
			}
		});
		
		btnSearch.setBounds(351, 43, 75, 21);
		frame.getContentPane().add(btnSearch);
		
		textAreaRemove = new JTextArea();
		textAreaRemove.setBounds(180, 70, 246, 126);
		frame.getContentPane().add(textAreaRemove);
		
		btnDelete = new JButton("Remove Cashier");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = textFieldRemove.getText().trim();
				
				
				if(id.isEmpty()) {
					JOptionPane.showMessageDialog( frame, "Please Add cashier ID number","Error",JOptionPane.WARNING_MESSAGE);
				}
				else {
					try {
							
							boolean isCashier = cashierService.deleteCashier(id);
							if(isCashier) {
								textFieldRemove.setText("");
								textAreaRemove.setText("\n\nCashier deleted sucessfully");
								
								JOptionPane.showMessageDialog( frame, "Cashier deleted sucessfully","Success",JOptionPane.PLAIN_MESSAGE);
						}else {
							textAreaRemove.setText("\n\nCan not delete Cashier");
							JOptionPane.showMessageDialog( frame, "Can not delete Cashier","Error",JOptionPane.WARNING_MESSAGE);
						}

					}catch (Exception ex) {
						textAreaRemove.setText("\n\nSomething went wrong..!");
						JOptionPane.showMessageDialog( frame, "Something went wrong","Error",JOptionPane.WARNING_MESSAGE);
						
					}
				}

			}
		});
		btnDelete.setBounds(274, 219, 152, 21);
		frame.getContentPane().add(btnDelete);
	}
}
