package cashiersubcriber;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import cashierpublisher.ICashier;
import cashierpublisher.Cashier;



public class CashierUI {
	private JFrame frame;

	private ICashier cashierService;
	
	
	JButton btnHome;
	JButton btnAddCashier;
	JButton btnAllCashier;
	JButton btnUpdateCashier;
	JButton btnRemoveCashier;
	JButton btnFindCashier;

	/**
	 * Create the application.
	 */
	public CashierUI(ICashier cashierService) {
		this.cashierService = cashierService;
		initialize();
	
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new MainUI(cashierService);
				frame.setVisible(false);
			}
		});
		
		btnAddCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AddCashierUI(cashierService);
				frame.setVisible(false);
			}
		});
		
		btnAllCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AllCashierUI(cashierService);
				frame.setVisible(false);
			}
		});
		
		btnUpdateCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new UpdateCashierUI(cashierService);
				frame.setVisible(false);
			}
		});
		
		btnRemoveCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new RemoveCashierUI(cashierService);
				frame.setVisible(false);
			}
		});
		
		btnFindCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new FindCashierUI(cashierService);
				frame.setVisible(false);
			}
		});
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);
		
		btnHome = new JButton("Home");
		btnHome.setBounds(10, 12, 140, 21);
		frame.getContentPane().add(btnHome);
		
		btnAddCashier = new JButton("Add Cashier");
		btnAddCashier.setBounds(10, 55, 140, 21);
		frame.getContentPane().add(btnAddCashier);
		
		btnAllCashier = new JButton("All Cashier");
		btnAllCashier.setBounds(10, 98, 140, 21);
		frame.getContentPane().add(btnAllCashier);
		
		btnUpdateCashier = new JButton("Update Cashier");
		btnUpdateCashier.setBounds(10, 144, 140, 21);
		frame.getContentPane().add(btnUpdateCashier);
		
		btnRemoveCashier = new JButton("Remove Cashier");
		btnRemoveCashier.setBounds(10, 188, 140, 21);
		frame.getContentPane().add(btnRemoveCashier);
		
		btnFindCashier = new JButton("Find Cashier");
		btnFindCashier.setBounds(10, 232, 140, 21);
		frame.getContentPane().add(btnFindCashier);
		
		
	}
}
