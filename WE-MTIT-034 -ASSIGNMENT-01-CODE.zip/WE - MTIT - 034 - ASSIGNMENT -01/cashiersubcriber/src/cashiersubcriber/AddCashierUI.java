package cashiersubcriber;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import cashierpublisher.Cashier;
import cashierpublisher.ICashier;






public class AddCashierUI {

	private JFrame frame;

	private ICashier cashierService;
	
	JButton btnHome;
	JButton btnAddCashier;
	JButton btnAllCashier;
	JButton btnUpdateCashier;
	JButton btnRemoveCashier;
	JButton btnFindCashier;
	private JLabel lblAddCashier;
	private JLabel lblCashierId;
	private JTextField textFieldCashierId;
	private JLabel lblCashierName;
	private JTextField textFieldCashierName;
	private JLabel lblAge;
	private JTextField textFieldAge;
	private JLabel lblAddress;
	private JTextField textFieldAddress;
	private JButton btnAdd;

	/**
	 * Create the application.
	 */
	public AddCashierUI(ICashier cashierService) {
		this.cashierService = cashierService;
		initialize();
	
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new MainUI(cashierService);
				frame.setVisible(false);
			}
		});
		
		btnAddCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AddCashierUI(cashierService);
				frame.setVisible(false);
			}
		});
		
		btnAllCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AllCashierUI(cashierService);
				frame.setVisible(false);
			}
		});
		
		btnUpdateCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new UpdateCashierUI(cashierService);
				frame.setVisible(false);
			}
		});
		
		btnRemoveCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new RemoveCashierUI(cashierService);
				frame.setVisible(false);
			}
		});
		
		btnFindCashier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new FindCashierUI(cashierService);
				frame.setVisible(false);
			}
		});
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);
		
		btnHome = new JButton("Home");
		btnHome.setBounds(10, 12, 140, 21);
		frame.getContentPane().add(btnHome);
		
		btnAddCashier = new JButton("Add Cashier");
		btnAddCashier.setBounds(10, 55, 140, 21);
		frame.getContentPane().add(btnAddCashier);
		
		btnAllCashier = new JButton("All Cashier");
		btnAllCashier.setBounds(10, 98, 140, 21);
		frame.getContentPane().add(btnAllCashier);
		
		btnUpdateCashier = new JButton("Update Cashier");
		btnUpdateCashier.setBounds(10, 144, 140, 21);
		frame.getContentPane().add(btnUpdateCashier);
		
		btnRemoveCashier = new JButton("Remove Cashier");
		btnRemoveCashier.setBounds(10, 188, 140, 21);
		frame.getContentPane().add(btnRemoveCashier);
		
		btnFindCashier = new JButton("Find Cashier");
		btnFindCashier.setBounds(10, 232, 140, 21);
		frame.getContentPane().add(btnFindCashier);
		
		lblAddCashier = new JLabel("Add Cashier");
		lblAddCashier.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblAddCashier.setBounds(248, 16, 124, 17);
		frame.getContentPane().add(lblAddCashier);
		
		lblCashierId = new JLabel("Cashier ID");
		lblCashierId.setBounds(198, 59, 96, 13);
		frame.getContentPane().add(lblCashierId);
		
		textFieldCashierId = new JTextField();
		textFieldCashierId.setBounds(304, 56, 122, 19);
		frame.getContentPane().add(textFieldCashierId);
		textFieldCashierId.setColumns(10);
		
		lblCashierName = new JLabel("Cashier Name");
		lblCashierName.setBounds(198, 102, 81, 13);
		frame.getContentPane().add(lblCashierName);
		
		textFieldCashierName = new JTextField();
		textFieldCashierName.setBounds(304, 99, 122, 19);
		frame.getContentPane().add(textFieldCashierName);
		textFieldCashierName.setColumns(10);
		
		lblAge = new JLabel("Age");
		lblAge.setBounds(198, 148, 81, 13);
		frame.getContentPane().add(lblAge);
		
		textFieldAge = new JTextField();
		textFieldAge.setBounds(304, 145, 122, 19);
		frame.getContentPane().add(textFieldAge);
		textFieldAge.setColumns(10);
		
		lblAddress = new JLabel("Address");
		lblAddress.setBounds(198, 192, 81, 13);
		frame.getContentPane().add(lblAddress);
		
		textFieldAddress = new JTextField();
		textFieldAddress.setBounds(304, 189, 122, 19);
		frame.getContentPane().add(textFieldAddress);
		textFieldAddress.setColumns(10);
		
		btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String id, name, age, Address;
				id = textFieldCashierId.getText().trim();
				name = textFieldCashierName.getText().trim();
				age = textFieldAge.getText().trim();
				Address = textFieldAddress.getText().trim();
				
				if(id.isEmpty()) {
					JOptionPane.showMessageDialog( frame, "Please Add cashier ID number","Error",JOptionPane.WARNING_MESSAGE);
				}
				else if(name.isEmpty()) {
					JOptionPane.showMessageDialog( frame, "Please add cashier name","Error",JOptionPane.WARNING_MESSAGE);
				}
				else if(age.isEmpty()) {
					JOptionPane.showMessageDialog( frame, "Please add age","Error",JOptionPane.WARNING_MESSAGE);
				}
				else if(Address.isEmpty()) {
					JOptionPane.showMessageDialog( frame, "Please add Address","Error",JOptionPane.WARNING_MESSAGE);
				}
				else {
					try {
							Cashier cashier = new Cashier(id,name, age, Address);
							boolean isCashier = cashierService.addCashier(cashier);
							if(isCashier) {
								textFieldCashierId.setText("");
								textFieldCashierName.setText("");
								textFieldAge.setText("");
								textFieldAddress.setText("");
								
								JOptionPane.showMessageDialog( frame, "Cashier add sucessfully","Success",JOptionPane.PLAIN_MESSAGE);
						}else {
							
							JOptionPane.showMessageDialog( frame, "Can not add Cashier","Error",JOptionPane.WARNING_MESSAGE);
						}

					}catch (Exception ex) {
						JOptionPane.showMessageDialog( frame, "Something went wrong","Error",JOptionPane.WARNING_MESSAGE);
						
					}
				}
				
				
			}
		});
		btnAdd.setBounds(266, 232, 85, 21);
		frame.getContentPane().add(btnAdd);
		
		
	}
}
