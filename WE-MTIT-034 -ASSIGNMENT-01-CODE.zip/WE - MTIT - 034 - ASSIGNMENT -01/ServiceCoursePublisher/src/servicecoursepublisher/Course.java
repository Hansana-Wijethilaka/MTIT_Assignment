package servicecoursepublisher;

public class Course {
	
	private int id;
	private String course_name;
	private String hall_no;
	
	public Course(int id, String course_name, String hall_no) {
		this.id = id;
		this.course_name = course_name;
		this.hall_no = hall_no;
	}

	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public String getCourse_name() {
		return course_name;
	}
	
	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}
	
	public String getHall_no() {
		return hall_no;
	}
	
	public void setHall_no(String hall_no) {
		this.hall_no = hall_no;
	}
	
}
