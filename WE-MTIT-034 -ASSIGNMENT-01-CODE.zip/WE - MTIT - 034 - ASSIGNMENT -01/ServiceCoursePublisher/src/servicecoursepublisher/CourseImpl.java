package servicecoursepublisher;

import java.util.ArrayList;

public class CourseImpl implements ICourse {
	
	private ArrayList<Course> courseList = new ArrayList<>();

	@Override
	public boolean addCourse(Course course) {
		System.out.println(course);
		courseList.add(course);
		return true;

	}

	@SuppressWarnings("unused")
	@Override
	public boolean updateCourse(int id, Course course) {
		
		for(Course newCourse : courseList) {

			if(course.getId() == id) {

				newCourse.setHall_no(course.getHall_no());
				newCourse.setCourse_name(newCourse.getCourse_name());
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean deleteCourse(int id) {
		
		if(courseList.isEmpty()) {
			return false;
		}
		else {
			for(Course course : courseList ) {
				if(course.getId() == id) {
					courseList.remove(course);
					return true;
				}
			}
		}
		return false;
	}

	@Override
	public Course get_by_id(int id) {

		if(courseList.isEmpty()) {
			return null;
			
		}else {
			for(Course course : courseList) {

				if(course.getId() == id) {
					return course;
				}
			}

			return null;
		}
		
	}

	@Override
	public ArrayList<Course> get_all() {
		if(courseList.isEmpty()) {
			return null;
			
		}else {
			return courseList;
			
		}
		
	}



}
