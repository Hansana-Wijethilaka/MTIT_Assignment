package servicecoursepublisher;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

public class Activator implements BundleActivator {

	public ServiceRegistration<?> serviceRegistration;

	public void start(BundleContext bundleContext) throws Exception {
		
		CourseImpl courseImpl = new CourseImpl();
		
		serviceRegistration = bundleContext.registerService(ICourse.class.getName(), courseImpl, null);
		
		System.out.println("Course Service Registered.");
	}

	public void stop(BundleContext bundleContext) throws Exception {
		
		serviceRegistration.unregister();
		
		System.out.println("Course Service Unregistered");
	}
}
