package servicecoursepublisher;

import java.util.ArrayList;

public interface ICourse {
	
	public boolean addCourse (Course course);
	public boolean updateCourse (int id, Course course);
	public boolean deleteCourse (int id);
	public Course get_by_id (int id);
	public ArrayList<Course> get_all();

}
