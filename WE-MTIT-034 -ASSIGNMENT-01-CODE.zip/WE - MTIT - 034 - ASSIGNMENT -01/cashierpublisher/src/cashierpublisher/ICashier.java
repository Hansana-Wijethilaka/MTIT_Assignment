package cashierpublisher;


import java.util.ArrayList;

public interface ICashier {

	public boolean addCashier(Cashier cashier);
	public boolean deleteCashier(String id);
	public Cashier cashier_get_by_id(String id);
	public ArrayList<Cashier> get_all_cashier();
	public boolean updateCashierList(String id, Cashier cashier);

}

