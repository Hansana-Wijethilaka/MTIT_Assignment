package cashierpublisher;


import java.util.ArrayList;



public class CashierImpl implements ICashier  {

	private ArrayList<Cashier> cashierList = new ArrayList<Cashier>();
	
	@Override
	public boolean addCashier(Cashier cashier) {
		cashierList.add(cashier);
		return true;
	}

	@Override
	public boolean deleteCashier(String id){
		if(cashierList.isEmpty()) {
			return false;
		}
		else {
			for(Cashier cashier : cashierList ) {
				if(cashier.getId().equals(id)) {
					cashierList.remove(cashier);
					return true;
				}
			}
			return false;
		}
	}

	@Override
	public Cashier cashier_get_by_id(String id) {
		if(cashierList.isEmpty()) {
			return null;
		}
		else {
			for(Cashier cashier : cashierList) {
				if(cashier.getId().equals(id)) {
					return cashier;
				}
			}
			return null;
		}
	}

	@Override
	public ArrayList<Cashier> get_all_cashier() {
		return cashierList;
	}

	@Override
	public boolean updateCashierList(String id, Cashier cashier) {
		if(cashierList.isEmpty()) {
			return false;
		}
		else {
			int i = -1;
			for(Cashier obj :cashierList) {
				i =i + 1;
				if(obj.getId().equals(id)) {
					cashierList.set(i, new Cashier(cashier.getId(),cashier.getName(),cashier.getAge(),cashier.getAddress()));
					return true;
				}
			}
			return false;
		}
	}

}
