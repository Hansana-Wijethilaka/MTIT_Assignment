package cashierpublisher;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;


public class Activator implements BundleActivator {

	private ServiceRegistration<?> serviceRegistration;


	public void start(BundleContext bundleContext) throws Exception {
		System.out.println("Cashier Publisher started");
		serviceRegistration = bundleContext.registerService(ICashier.class.getName(), new CashierImpl(), null);
	}

	public void stop(BundleContext bundleContext) throws Exception {
		System.out.println("Cashier Publisher stopped");
		serviceRegistration.unregister();
	}

}

